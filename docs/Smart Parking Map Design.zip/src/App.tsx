import { useState } from 'react'

// ─── Types ───────────────────────────────────────────────────────────────────

type SlotStatus = 'available' | 'occupied' | 'reserved' | 'ev' | 'accessible' | 'disabled'
type VehicleType = 'car' | 'motorcycle' | 'ev'

interface ParkingSlot {
  id: string
  status: SlotStatus
  vehicleType: VehicleType
  zone: string
  floor: string
  lastUpdated: string
  resident?: string
  plate?: string
}

type FloorData = {
  [floor: string]: ParkingSlot[]
}

// ─── Data ─────────────────────────────────────────────────────────────────────

const generateSlots = (): FloorData => ({
  B1: [
    // Zone A — Row 1 (top)
    { id: 'P01', status: 'occupied',   vehicleType: 'car',        zone: 'A', floor: 'B1', lastUpdated: '2 min ago',  plate: 'กข 1234' },
    { id: 'P02', status: 'available',  vehicleType: 'car',        zone: 'A', floor: 'B1', lastUpdated: 'Just now' },
    { id: 'P03', status: 'available',  vehicleType: 'car',        zone: 'A', floor: 'B1', lastUpdated: '5 min ago' },
    { id: 'P04', status: 'occupied',   vehicleType: 'car',        zone: 'A', floor: 'B1', lastUpdated: '18 min ago', plate: 'คง 5678' },
    { id: 'P05', status: 'reserved',   vehicleType: 'car',        zone: 'A', floor: 'B1', lastUpdated: '1 hr ago',   resident: 'Unit 12A' },
    // Zone A — Row 2
    { id: 'P06', status: 'available',  vehicleType: 'car',        zone: 'A', floor: 'B1', lastUpdated: 'Just now' },
    { id: 'P07', status: 'available',  vehicleType: 'car',        zone: 'A', floor: 'B1', lastUpdated: 'Just now' },
    { id: 'P08', status: 'occupied',   vehicleType: 'car',        zone: 'A', floor: 'B1', lastUpdated: '34 min ago', plate: 'งจ 9012' },
    { id: 'P09', status: 'occupied',   vehicleType: 'car',        zone: 'A', floor: 'B1', lastUpdated: '1 hr ago',   plate: 'จฉ 3456' },
    { id: 'P10', status: 'reserved',   vehicleType: 'car',        zone: 'A', floor: 'B1', lastUpdated: '3 hr ago',   resident: 'Unit 8B' },
    // Zone B — Row 3
    { id: 'P11', status: 'occupied',   vehicleType: 'car',        zone: 'B', floor: 'B1', lastUpdated: '45 min ago', plate: 'ชซ 7890' },
    { id: 'P12', status: 'available',  vehicleType: 'car',        zone: 'B', floor: 'B1', lastUpdated: 'Just now' },
    { id: 'P13', status: 'available',  vehicleType: 'car',        zone: 'B', floor: 'B1', lastUpdated: 'Just now' },
    { id: 'P14', status: 'occupied',   vehicleType: 'car',        zone: 'B', floor: 'B1', lastUpdated: '7 min ago',  plate: 'ฌญ 2345' },
    { id: 'P15', status: 'disabled',   vehicleType: 'car',        zone: 'B', floor: 'B1', lastUpdated: '2 days ago' },
    // Zone B — Row 4
    { id: 'P16', status: 'available',  vehicleType: 'car',        zone: 'B', floor: 'B1', lastUpdated: 'Just now' },
    { id: 'P17', status: 'reserved',   vehicleType: 'car',        zone: 'B', floor: 'B1', lastUpdated: '5 hr ago',   resident: 'Unit 3C' },
    { id: 'P18', status: 'occupied',   vehicleType: 'car',        zone: 'B', floor: 'B1', lastUpdated: '22 min ago', plate: 'ณด 6789' },
    { id: 'P19', status: 'available',  vehicleType: 'car',        zone: 'B', floor: 'B1', lastUpdated: '3 min ago' },
    { id: 'P20', status: 'occupied',   vehicleType: 'car',        zone: 'B', floor: 'B1', lastUpdated: '1 hr ago',   plate: 'ตถ 0123' },
    // Accessible
    { id: 'A-01', status: 'accessible', vehicleType: 'car',       zone: 'A', floor: 'B1', lastUpdated: 'Just now' },
    { id: 'A-02', status: 'occupied',   vehicleType: 'car',       zone: 'B', floor: 'B1', lastUpdated: '3 hr ago',  plate: 'ทธ 4567' },
    // EV Charging
    { id: 'EV-01', status: 'ev',        vehicleType: 'ev',        zone: 'C', floor: 'B1', lastUpdated: 'Just now' },
    { id: 'EV-02', status: 'ev',        vehicleType: 'ev',        zone: 'C', floor: 'B1', lastUpdated: '12 min ago' },
    { id: 'EV-03', status: 'ev',        vehicleType: 'ev',        zone: 'C', floor: 'B1', lastUpdated: 'Just now' },
    // Motorcycles
    { id: 'M01', status: 'occupied',   vehicleType: 'motorcycle', zone: 'M', floor: 'B1', lastUpdated: '40 min ago', plate: 'นบ 111' },
    { id: 'M02', status: 'available',  vehicleType: 'motorcycle', zone: 'M', floor: 'B1', lastUpdated: 'Just now' },
    { id: 'M03', status: 'available',  vehicleType: 'motorcycle', zone: 'M', floor: 'B1', lastUpdated: 'Just now' },
    { id: 'M04', status: 'occupied',   vehicleType: 'motorcycle', zone: 'M', floor: 'B1', lastUpdated: '55 min ago', plate: 'ปผ 222' },
    { id: 'M05', status: 'available',  vehicleType: 'motorcycle', zone: 'M', floor: 'B1', lastUpdated: 'Just now' },
    { id: 'M06', status: 'occupied',   vehicleType: 'motorcycle', zone: 'M', floor: 'B1', lastUpdated: '15 min ago', plate: 'ฝพ 333' },
  ],
  B2: [
    { id: 'P21', status: 'available',  vehicleType: 'car', zone: 'A', floor: 'B2', lastUpdated: 'Just now' },
    { id: 'P22', status: 'occupied',   vehicleType: 'car', zone: 'A', floor: 'B2', lastUpdated: '8 min ago',  plate: 'ฟภ 1111' },
    { id: 'P23', status: 'available',  vehicleType: 'car', zone: 'A', floor: 'B2', lastUpdated: 'Just now' },
    { id: 'P24', status: 'reserved',   vehicleType: 'car', zone: 'A', floor: 'B2', lastUpdated: '2 hr ago',  resident: 'Unit 15D' },
    { id: 'P25', status: 'occupied',   vehicleType: 'car', zone: 'A', floor: 'B2', lastUpdated: '30 min ago', plate: 'มย 2222' },
    { id: 'P26', status: 'available',  vehicleType: 'car', zone: 'B', floor: 'B2', lastUpdated: 'Just now' },
    { id: 'P27', status: 'available',  vehicleType: 'car', zone: 'B', floor: 'B2', lastUpdated: 'Just now' },
    { id: 'P28', status: 'occupied',   vehicleType: 'car', zone: 'B', floor: 'B2', lastUpdated: '1 hr ago',  plate: 'รล 3333' },
    { id: 'P29', status: 'available',  vehicleType: 'car', zone: 'B', floor: 'B2', lastUpdated: 'Just now' },
    { id: 'P30', status: 'occupied',   vehicleType: 'car', zone: 'B', floor: 'B2', lastUpdated: '20 min ago', plate: 'วศ 4444' },
    { id: 'EV-04', status: 'ev',       vehicleType: 'ev',  zone: 'C', floor: 'B2', lastUpdated: 'Just now' },
    { id: 'EV-05', status: 'ev',       vehicleType: 'ev',  zone: 'C', floor: 'B2', lastUpdated: '5 min ago' },
    { id: 'A-03', status: 'accessible', vehicleType: 'car', zone: 'A', floor: 'B2', lastUpdated: 'Just now' },
    { id: 'M07', status: 'available',  vehicleType: 'motorcycle', zone: 'M', floor: 'B2', lastUpdated: 'Just now' },
    { id: 'M08', status: 'occupied',   vehicleType: 'motorcycle', zone: 'M', floor: 'B2', lastUpdated: '35 min ago', plate: 'สห 555' },
    { id: 'M09', status: 'available',  vehicleType: 'motorcycle', zone: 'M', floor: 'B2', lastUpdated: 'Just now' },
  ],
  B3: [
    { id: 'P31', status: 'available',  vehicleType: 'car', zone: 'A', floor: 'B3', lastUpdated: 'Just now' },
    { id: 'P32', status: 'available',  vehicleType: 'car', zone: 'A', floor: 'B3', lastUpdated: 'Just now' },
    { id: 'P33', status: 'occupied',   vehicleType: 'car', zone: 'A', floor: 'B3', lastUpdated: '45 min ago', plate: 'ฬอ 6666' },
    { id: 'P34', status: 'available',  vehicleType: 'car', zone: 'A', floor: 'B3', lastUpdated: 'Just now' },
    { id: 'P35', status: 'reserved',   vehicleType: 'car', zone: 'A', floor: 'B3', lastUpdated: '4 hr ago',  resident: 'Unit 20E' },
    { id: 'P36', status: 'available',  vehicleType: 'car', zone: 'B', floor: 'B3', lastUpdated: 'Just now' },
    { id: 'P37', status: 'available',  vehicleType: 'car', zone: 'B', floor: 'B3', lastUpdated: 'Just now' },
    { id: 'P38', status: 'available',  vehicleType: 'car', zone: 'B', floor: 'B3', lastUpdated: 'Just now' },
    { id: 'P39', status: 'occupied',   vehicleType: 'car', zone: 'B', floor: 'B3', lastUpdated: '12 min ago', plate: 'ฮฯ 7777' },
    { id: 'P40', status: 'available',  vehicleType: 'car', zone: 'B', floor: 'B3', lastUpdated: 'Just now' },
    { id: 'EV-06', status: 'ev',       vehicleType: 'ev',  zone: 'C', floor: 'B3', lastUpdated: 'Just now' },
    { id: 'A-04', status: 'accessible', vehicleType: 'car', zone: 'A', floor: 'B3', lastUpdated: 'Just now' },
    { id: 'M10', status: 'available',  vehicleType: 'motorcycle', zone: 'M', floor: 'B3', lastUpdated: 'Just now' },
    { id: 'M11', status: 'available',  vehicleType: 'motorcycle', zone: 'M', floor: 'B3', lastUpdated: 'Just now' },
  ],
})

const FLOOR_STATS: Record<string, { total: number; available: number; occupied: number; reserved: number }> = {
  B1: { total: 120, available: 42, occupied: 68, reserved: 10 },
  B2: { total: 80,  available: 31, occupied: 40, reserved: 9 },
  B3: { total: 60,  available: 48, occupied: 8,  reserved: 4 },
}
const EV_COUNT = { B1: 6, B2: 4, B3: 2 }

// ─── Icons (inline SVG) ───────────────────────────────────────────────────────

type IconProps = { className?: string; style?: React.CSSProperties }

const CarIcon = ({ className = '', style }: IconProps) => (
  <svg className={className} style={style} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <path d="M5 17H3v-4l2-5h14l2 5v4h-2" />
    <circle cx="7" cy="17" r="2" /><circle cx="17" cy="17" r="2" />
    <path d="M5 13h14" />
  </svg>
)

const MotoIcon = ({ className = '', style }: IconProps) => (
  <svg className={className} style={style} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="5" cy="17" r="3" /><circle cx="19" cy="17" r="3" />
    <path d="M5 17h14M9 17l2-5h4l2 5M12 12V7l4 2" />
  </svg>
)

const BoltIcon = ({ className = '', style }: IconProps) => (
  <svg className={className} style={style} viewBox="0 0 24 24" fill="currentColor">
    <path d="M13 2L4.09 12.97A.5.5 0 0 0 4.5 14H11l-1 8 8.91-10.97A.5.5 0 0 0 18.5 10H12l1-8z" />
  </svg>
)

const AccessibleIcon = ({ className = '', style }: IconProps) => (
  <svg className={className} style={style} viewBox="0 0 24 24" fill="currentColor">
    <circle cx="12" cy="4" r="2" />
    <path d="M10 9h4l2 5h3v2h-4l-1-2.5V17l2 1v4h-2l-2-1.5L10 22H8v-4l2-1v-3.5L9 16H5v-2h3l2-5z" />
  </svg>
)

const ParkIcon = ({ className = '', style }: IconProps) => (
  <svg className={className} style={style} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <rect x="3" y="3" width="18" height="18" rx="2" />
    <path d="M9 17V7h4a3 3 0 0 1 0 6H9" />
  </svg>
)

const LockIcon = ({ className = '', style }: IconProps) => (
  <svg className={className} style={style} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <rect x="3" y="11" width="18" height="11" rx="2" ry="2" />
    <path d="M7 11V7a5 5 0 0 1 10 0v4" />
  </svg>
)

const ChevronRightIcon = ({ className = '', style }: IconProps) => (
  <svg className={className} style={style} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <polyline points="9 18 15 12 9 6" />
  </svg>
)

const CloseIcon = ({ className = '', style }: IconProps) => (
  <svg className={className} style={style} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <line x1="18" y1="6" x2="6" y2="18" /><line x1="6" y1="6" x2="18" y2="18" />
  </svg>
)

const MoonIcon = ({ className = '', style }: IconProps) => (
  <svg className={className} style={style} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z" />
  </svg>
)

const SunIcon = ({ className = '', style }: IconProps) => (
  <svg className={className} style={style} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="12" cy="12" r="5" />
    <line x1="12" y1="1" x2="12" y2="3" /><line x1="12" y1="21" x2="12" y2="23" />
    <line x1="4.22" y1="4.22" x2="5.64" y2="5.64" /><line x1="18.36" y1="18.36" x2="19.78" y2="19.78" />
    <line x1="1" y1="12" x2="3" y2="12" /><line x1="21" y1="12" x2="23" y2="12" />
    <line x1="4.22" y1="19.78" x2="5.64" y2="18.36" /><line x1="18.36" y1="5.64" x2="19.78" y2="4.22" />
  </svg>
)


// ─── Slot config ──────────────────────────────────────────────────────────────

const statusConfig = {
  available:   { bg: '#DCFCE7', border: '#22C55E', text: '#15803D', label: 'Available' },
  occupied:    { bg: '#FEE2E2', border: '#EF4444', text: '#B91C1C', label: 'Occupied' },
  reserved:    { bg: '#FEF3C7', border: '#F59E0B', text: '#92400E', label: 'Reserved' },
  ev:          { bg: '#E8F5ED', border: '#0F6B4F', text: '#0F6B4F', label: 'EV Charging' },
  accessible:  { bg: '#E8F5ED', border: '#0F6B4F', text: '#0F6B4F', label: 'Accessible' },
  disabled:    { bg: '#F3F4F6', border: '#D1D5DB', text: '#9CA3AF', label: 'Unavailable' },
}

const darkStatusConfig = {
  available:   { bg: '#052E16', border: '#22C55E', text: '#4ADE80' },
  occupied:    { bg: '#450A0A', border: '#EF4444', text: '#FCA5A5' },
  reserved:    { bg: '#451A03', border: '#F59E0B', text: '#FCD34D' },
  ev:          { bg: '#022C22', border: '#0F6B4F', text: '#34D399' },
  accessible:  { bg: '#022C22', border: '#0F6B4F', text: '#34D399' },
  disabled:    { bg: '#1F2937', border: '#374151', text: '#4B5563' },
}

// ─── Parking Slot Component ───────────────────────────────────────────────────

interface ParkingSlotProps {
  slot: ParkingSlot
  selected: boolean
  darkMode: boolean
  onClick: () => void
  small?: boolean
}

function ParkingSlotCard({ slot, selected, darkMode, onClick, small = false }: ParkingSlotProps) {
  const cfg = darkMode ? darkStatusConfig[slot.status] : statusConfig[slot.status]
  const isMotorcycle = slot.vehicleType === 'motorcycle'

  const borderColor = selected ? '#0F6B4F' : cfg.border
  const bgColor = selected
    ? (darkMode ? '#022C22' : '#E8F5ED')
    : cfg.bg
  const shadow = selected
    ? '0 0 0 3px rgba(15,107,79,0.35), 0 4px 12px rgba(0,0,0,0.15)'
    : '0 1px 3px rgba(0,0,0,0.08)'

  const IconComp = slot.status === 'ev'
    ? BoltIcon
    : slot.status === 'accessible'
    ? AccessibleIcon
    : slot.vehicleType === 'motorcycle'
    ? MotoIcon
    : CarIcon

  const iconColor = selected ? '#0F6B4F' : cfg.text

  if (small) {
    return (
      <button
        onClick={onClick}
        style={{ background: bgColor, border: `1.5px solid ${borderColor}`, boxShadow: shadow, width: 52, height: 40 }}
        className="relative rounded-md flex flex-col items-center justify-center gap-0.5 transition-all duration-150 hover:scale-105 cursor-pointer"
      >
        <span style={{ fontFamily: "'DM Mono', monospace", fontSize: 9, fontWeight: 500, color: iconColor, lineHeight: 1 }}>{slot.id}</span>
        <IconComp className="w-4 h-4" style={{ color: iconColor }} />
      </button>
    )
  }

  return (
    <button
      onClick={onClick}
      style={{ background: bgColor, border: `1.5px solid ${borderColor}`, boxShadow: shadow }}
      className="relative rounded-lg flex flex-col items-center justify-center gap-1 transition-all duration-150 hover:scale-[1.03] hover:shadow-md cursor-pointer w-full h-full"
    >
      {/* Slot status badge */}
      {slot.status === 'ev' && (
        <div className="absolute top-1 right-1 w-4 h-4 rounded-full flex items-center justify-center" style={{ background: '#0F6B4F' }}>
          <BoltIcon className="w-2.5 h-2.5 text-white" />
        </div>
      )}
      {slot.status === 'accessible' && (
        <div className="absolute top-1 right-1 w-4 h-4 rounded-full flex items-center justify-center" style={{ background: '#0F6B4F' }}>
          <AccessibleIcon className="w-2.5 h-2.5 text-white" />
        </div>
      )}
      {slot.status === 'reserved' && (
        <div className="absolute top-1 right-1 w-4 h-4 rounded-full flex items-center justify-center" style={{ background: '#F59E0B' }}>
          <LockIcon className="w-2.5 h-2.5 text-white" />
        </div>
      )}

      <span style={{ fontFamily: "'DM Mono', monospace", fontSize: 10, fontWeight: 500, color: iconColor, letterSpacing: '0.02em' }}>
        {slot.id}
      </span>

      <IconComp className="w-5 h-5" />

      <span style={{ fontSize: 8, fontWeight: 600, color: iconColor, letterSpacing: '0.06em', textTransform: 'uppercase' }}>
        {slot.status === 'ev' ? 'EV' : slot.status === 'accessible' ? 'ACCESS' : slot.status === 'disabled' ? 'N/A' : slot.status.slice(0, 4).toUpperCase()}
      </span>
    </button>
  )
}

// ─── Detail Panel ─────────────────────────────────────────────────────────────

function DetailPanel({ slot, darkMode, onClose }: { slot: ParkingSlot; darkMode: boolean; onClose: () => void }) {
  const cfg = statusConfig[slot.status]
  const labelMap: Record<SlotStatus, string> = {
    available: 'Available', occupied: 'Occupied', reserved: 'Reserved',
    ev: 'EV Charging', accessible: 'Accessible', disabled: 'Unavailable',
  }
  const vehicleLabel: Record<VehicleType, string> = {
    car: 'Car', motorcycle: 'Motorcycle', ev: 'Electric Vehicle',
  }

  const bg = darkMode ? 'hsl(160 20% 9%)' : '#FFFFFF'
  const cardBg = darkMode ? 'hsl(160 25% 6%)' : '#F9FAFB'
  const borderColor = darkMode ? 'rgba(255,255,255,0.07)' : '#E5E7EB'
  const textMain = darkMode ? 'hsl(150 15% 96%)' : '#1F2937'
  const textMuted = darkMode ? '#6B7280' : '#6B7280'

  return (
    <div className="panel-slide-in h-full flex flex-col" style={{ background: bg, borderLeft: `1px solid ${borderColor}` }}>
      {/* Panel header */}
      <div className="flex items-center justify-between px-5 py-4" style={{ borderBottom: `1px solid ${borderColor}` }}>
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg flex items-center justify-center" style={{ background: '#E8F5ED' }}>
            <ParkIcon className="w-5 h-5" style={{ color: '#0F6B4F' }} />
          </div>
          <div>
            <div style={{ fontFamily: "'DM Mono', monospace", fontSize: 18, fontWeight: 600, color: textMain, letterSpacing: '0.02em' }}>
              {slot.id}
            </div>
            <div style={{ fontSize: 12, color: textMuted }}>Parking Space Detail</div>
          </div>
        </div>
        <button onClick={onClose} className="w-8 h-8 rounded-lg flex items-center justify-center hover:opacity-70 transition-opacity" style={{ background: cardBg }}>
          <CloseIcon className="w-4 h-4" style={{ color: textMuted }} />
        </button>
      </div>

      {/* Status badge */}
      <div className="px-5 py-4">
        <div className="rounded-xl px-4 py-3 flex items-center justify-between" style={{ background: cfg.bg, border: `1px solid ${cfg.border}` }}>
          <span style={{ fontSize: 14, fontWeight: 600, color: cfg.text }}>{labelMap[slot.status]}</span>
          <div className="w-2.5 h-2.5 rounded-full" style={{ background: cfg.border }} />
        </div>
      </div>

      {/* Details grid */}
      <div className="px-5 flex flex-col gap-2 flex-1 overflow-y-auto">
        {[
          { label: 'Vehicle Type', value: vehicleLabel[slot.vehicleType] },
          { label: 'Floor', value: slot.floor },
          { label: 'Zone', value: `Zone ${slot.zone}` },
          { label: 'Status', value: labelMap[slot.status] },
          { label: 'Last Updated', value: slot.lastUpdated },
          ...(slot.plate ? [{ label: 'License Plate', value: slot.plate }] : []),
          ...(slot.resident ? [{ label: 'Reserved For', value: slot.resident }] : []),
        ].map(({ label, value }) => (
          <div key={label} className="flex items-center justify-between rounded-lg px-3 py-2.5" style={{ background: cardBg }}>
            <span style={{ fontSize: 12, color: textMuted, fontWeight: 500 }}>{label}</span>
            <span style={{ fontSize: 13, fontWeight: 600, color: textMain, fontFamily: label === 'License Plate' ? "'DM Mono', monospace" : 'inherit' }}>{value}</span>
          </div>
        ))}

        {/* EV info */}
        {slot.status === 'ev' && (
          <div className="rounded-xl p-3 mt-1" style={{ background: '#E8F5ED', border: '1px solid #BBF7D0' }}>
            <div className="flex items-center gap-2 mb-1">
              <BoltIcon className="w-4 h-4" style={{ color: '#0F6B4F' }} />
              <span style={{ fontSize: 12, fontWeight: 600, color: '#0F6B4F' }}>EV Charging Point</span>
            </div>
            <p style={{ fontSize: 11, color: '#15803D' }}>22 kW AC Fast Charging • Available</p>
          </div>
        )}
      </div>

      {/* Action button */}
      <div className="px-5 py-4" style={{ borderTop: `1px solid ${borderColor}` }}>
        {slot.status === 'available' || slot.status === 'ev' || slot.status === 'accessible' ? (
          <button className="w-full py-3 rounded-xl text-white font-semibold text-sm transition-all hover:opacity-90 active:scale-[0.98]"
            style={{ background: '#0F6B4F', fontSize: 14, letterSpacing: '0.01em' }}>
            Reserve Parking
          </button>
        ) : slot.status === 'occupied' ? (
          <button className="w-full py-3 rounded-xl font-semibold text-sm transition-all hover:opacity-90"
            style={{ background: '#FEE2E2', color: '#B91C1C', border: '1px solid #FECACA', fontSize: 14 }}>
            Report Issue
          </button>
        ) : (
          <button className="w-full py-3 rounded-xl font-semibold text-sm"
            style={{ background: '#F3F4F6', color: '#9CA3AF', fontSize: 14, cursor: 'default' }} disabled>
            Not Available
          </button>
        )}
      </div>
    </div>
  )
}

// ─── Main App ─────────────────────────────────────────────────────────────────

export default function App() {
  const [floor, setFloor] = useState<'B1' | 'B2' | 'B3'>('B1')
  const [selected, setSelected] = useState<string | null>('P07')
  const [darkMode, setDarkMode] = useState(false)
  const allSlots = generateSlots()
  const slots = allSlots[floor]
  const selectedSlot = slots.find(s => s.id === selected) ?? null
  const stats = FLOOR_STATS[floor]
  const evCount = EV_COUNT[floor as keyof typeof EV_COUNT]

  const bg = darkMode ? 'hsl(160 25% 6%)' : '#F4F7F5'
  const surface = darkMode ? 'hsl(160 20% 9%)' : '#FFFFFF'
  const mapBg = darkMode ? 'hsl(160 22% 8%)' : '#EFF4F1'
  const borderColor = darkMode ? 'rgba(255,255,255,0.07)' : '#E5E7EB'
  const laneColor = darkMode ? 'rgba(255,255,255,0.04)' : 'rgba(0,0,0,0.04)'
  const textMain = darkMode ? 'hsl(150 15% 96%)' : '#1F2937'
  const textMuted = darkMode ? '#6B7280' : '#6B7280'

  // Split slots for B1 map
  const zoneA_row1 = slots.filter(s => ['P01','P02','P03','P04','P05'].includes(s.id))
  const zoneA_row2 = slots.filter(s => ['P06','P07','P08','P09','P10'].includes(s.id))
  const zoneB_row1 = slots.filter(s => ['P11','P12','P13','P14','P15'].includes(s.id))
  const zoneB_row2 = slots.filter(s => ['P16','P17','P18','P19','P20'].includes(s.id))
  const accessible = slots.filter(s => s.status === 'accessible')
  const evSlots = slots.filter(s => s.status === 'ev')
  const motoSlots = slots.filter(s => s.vehicleType === 'motorcycle')
  // For B2/B3
  const carSlots = slots.filter(s => s.vehicleType === 'car' && s.status !== 'accessible')
  const carRow1 = carSlots.slice(0, 5)
  const carRow2 = carSlots.slice(5, 10)

  return (
    <div className="min-h-screen flex flex-col" style={{ background: bg, fontFamily: "'DM Sans', sans-serif", color: textMain }}>

      {/* ── Top Navigation Bar ── */}
      <header style={{ background: surface, borderBottom: `1px solid ${borderColor}` }} className="flex items-center justify-between px-6 py-3.5 sticky top-0 z-50">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: '#0F6B4F' }}>
            <svg viewBox="0 0 24 24" fill="white" className="w-4 h-4">
              <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
              <polyline points="9 22 9 12 15 12 15 22" />
            </svg>
          </div>
          <div>
            <div style={{ fontSize: 15, fontWeight: 700, color: textMain, letterSpacing: '-0.01em' }}>Arbor Living</div>
            <div style={{ fontSize: 11, color: textMuted }}>Smart Apartment Management</div>
          </div>
        </div>

        <nav className="hidden md:flex items-center gap-1">
          {['Dashboard', 'Residents', 'Parking', 'Maintenance', 'Reports'].map(item => (
            <button key={item} className="px-3.5 py-1.5 rounded-lg text-sm font-medium transition-colors"
              style={{
                background: item === 'Parking' ? '#E8F5ED' : 'transparent',
                color: item === 'Parking' ? '#0F6B4F' : textMuted,
                fontWeight: item === 'Parking' ? 600 : 400,
              }}>
              {item}
            </button>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <button onClick={() => setDarkMode(!darkMode)} className="w-8 h-8 rounded-lg flex items-center justify-center transition-colors hover:opacity-70"
            style={{ background: darkMode ? 'rgba(255,255,255,0.08)' : '#F3F4F6' }}>
            {darkMode ? <SunIcon className="w-4 h-4" style={{ color: '#FCD34D' }} /> : <MoonIcon className="w-4 h-4" style={{ color: textMuted }} />}
          </button>
          <div className="w-8 h-8 rounded-full flex items-center justify-center text-white text-xs font-bold" style={{ background: '#0F6B4F' }}>SM</div>
        </div>
      </header>

      {/* ── Page Content ── */}
      <div className="flex flex-1 overflow-hidden" style={{ minHeight: 0 }}>

        {/* ── Main area ── */}
        <main className="flex-1 flex flex-col overflow-auto p-5 gap-4" style={{ minWidth: 0 }}>

          {/* Page header */}
          <div className="flex items-center gap-2 text-sm" style={{ color: textMuted }}>
            <span>Parking Management</span>
            <ChevronRightIcon className="w-3.5 h-3.5" />
            <span style={{ color: '#0F6B4F', fontWeight: 600 }}>Parking Map</span>
          </div>

          <div className="flex items-start justify-between flex-wrap gap-3">
            <div>
              <h1 style={{ fontSize: 22, fontWeight: 700, color: textMain, letterSpacing: '-0.02em', lineHeight: 1.2 }}>Smart Parking Map</h1>
              <p style={{ fontSize: 13, color: textMuted, marginTop: 2 }}>{floor} — Basement Parking • Real-time status</p>
            </div>

            {/* Floor Selector */}
            <div className="flex items-center gap-1 p-1 rounded-xl" style={{ background: darkMode ? 'rgba(255,255,255,0.06)' : '#E5E7EB' }}>
              {(['B1', 'B2', 'B3'] as const).map(f => (
                <button key={f} onClick={() => { setFloor(f); setSelected(null); }}
                  className="px-5 py-2 rounded-lg text-sm font-semibold transition-all"
                  style={{
                    background: floor === f ? '#0F6B4F' : 'transparent',
                    color: floor === f ? '#FFFFFF' : textMuted,
                    boxShadow: floor === f ? '0 2px 8px rgba(15,107,79,0.35)' : 'none',
                    fontFamily: "'DM Mono', monospace",
                    letterSpacing: '0.04em',
                  }}>
                  {f}
                </button>
              ))}
            </div>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
            {[
              { label: 'Total Spaces', value: stats.total,     color: textMain,   bg: surface,      border: borderColor },
              { label: 'Available',    value: stats.available, color: '#15803D',  bg: '#DCFCE7',    border: '#22C55E' },
              { label: 'Occupied',     value: stats.occupied,  color: '#B91C1C',  bg: '#FEE2E2',    border: '#EF4444' },
              { label: 'Reserved',     value: stats.reserved,  color: '#92400E',  bg: '#FEF3C7',    border: '#F59E0B' },
              { label: 'EV Charging',  value: evCount,         color: '#0F6B4F',  bg: '#E8F5ED',    border: '#0F6B4F' },
            ].map(card => (
              <div key={card.label} className="rounded-xl px-4 py-3 flex flex-col gap-1"
                style={{ background: card.bg, border: `1.5px solid ${card.border}` }}>
                <div style={{ fontSize: 22, fontWeight: 700, color: card.color, fontFamily: "'DM Mono', monospace", letterSpacing: '-0.02em' }}>
                  {card.value}
                </div>
                <div style={{ fontSize: 11, color: card.color, fontWeight: 500, opacity: 0.8, textTransform: 'uppercase', letterSpacing: '0.06em' }}>
                  {card.label}
                </div>
                {card.label !== 'Total Spaces' && (
                  <div className="w-full h-1 rounded-full mt-1" style={{ background: 'rgba(0,0,0,0.08)' }}>
                    <div className="h-full rounded-full" style={{ width: `${Math.round((card.value / stats.total) * 100)}%`, background: card.border }} />
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* ── Parking Map ── */}
          <div className="rounded-2xl flex-1 overflow-hidden" style={{ background: surface, border: `1px solid ${borderColor}`, minHeight: 440 }}>
            {/* Map header */}
            <div className="flex items-center justify-between px-5 py-3.5" style={{ borderBottom: `1px solid ${borderColor}` }}>
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 rounded-full bg-green-500" style={{ boxShadow: '0 0 0 3px rgba(34,197,94,0.2)' }} />
                <span style={{ fontSize: 13, fontWeight: 600, color: textMain }}>Live Parking Map — {floor}</span>
                <span style={{ fontSize: 11, color: textMuted }}>Updated just now</span>
              </div>
              {/* Legend */}
              <div className="hidden sm:flex items-center gap-4">
                {[
                  { color: '#22C55E', label: 'Available' },
                  { color: '#EF4444', label: 'Occupied' },
                  { color: '#F59E0B', label: 'Reserved' },
                  { color: '#0F6B4F', label: 'EV / Accessible' },
                  { color: '#D1D5DB', label: 'Unavailable' },
                ].map(l => (
                  <div key={l.label} className="flex items-center gap-1.5">
                    <div className="w-2.5 h-2.5 rounded-sm" style={{ background: l.color }} />
                    <span style={{ fontSize: 11, color: textMuted }}>{l.label}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Map canvas */}
            <div className="relative p-5 overflow-auto" style={{ background: mapBg }}>

              {/* ENTRY label */}
              <div className="flex items-center gap-3 mb-3">
                <div className="rounded-lg px-3 py-1.5 flex items-center gap-2" style={{ background: '#0F6B4F' }}>
                  <svg viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" className="w-3.5 h-3.5">
                    <path d="M12 19V5M5 12l7-7 7 7" />
                  </svg>
                  <span style={{ fontSize: 11, fontWeight: 700, color: 'white', letterSpacing: '0.08em', fontFamily: "'DM Mono', monospace" }}>ENTRY</span>
                </div>
                {/* Security booth */}
                <div className="rounded-lg px-3 py-1.5 flex items-center gap-2" style={{ background: surface, border: `1px solid ${borderColor}` }}>
                  <svg viewBox="0 0 24 24" fill="none" stroke={textMuted} strokeWidth="1.5" className="w-3.5 h-3.5">
                    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
                  </svg>
                  <span style={{ fontSize: 10, fontWeight: 600, color: textMuted, letterSpacing: '0.06em', fontFamily: "'DM Mono', monospace" }}>SECURITY</span>
                </div>
              </div>

              {/* Traffic lane indicator — entry */}
              <div className="flex items-center gap-2 mb-3">
                <div className="flex-1 h-px" style={{ background: 'repeating-linear-gradient(90deg, #0F6B4F 0, #0F6B4F 12px, transparent 12px, transparent 22px)' }} />
                <span style={{ fontSize: 9, fontWeight: 700, color: '#0F6B4F', letterSpacing: '0.1em', fontFamily: "'DM Mono', monospace" }}>→ LANE A →</span>
                <div className="flex-1 h-px" style={{ background: 'repeating-linear-gradient(90deg, #0F6B4F 0, #0F6B4F 12px, transparent 12px, transparent 22px)' }} />
              </div>

              {/* Zone A label + Row 1 */}
              <div className="mb-2">
                <div className="flex items-center gap-2 mb-2">
                  <span style={{ fontSize: 10, fontWeight: 700, color: textMuted, letterSpacing: '0.1em', fontFamily: "'DM Mono', monospace" }}>ZONE A</span>
                  <div className="flex-1 h-px" style={{ background: borderColor }} />
                </div>
                <div className="grid gap-2" style={{ gridTemplateColumns: `repeat(${floor === 'B1' ? 5 : 5}, minmax(0, 1fr))` }}>
                  {(floor === 'B1' ? zoneA_row1 : carRow1).map(slot => (
                    <div key={slot.id} style={{ height: 72 }}>
                      <ParkingSlotCard slot={slot} selected={selected === slot.id} darkMode={darkMode} onClick={() => setSelected(s => s === slot.id ? null : slot.id)} />
                    </div>
                  ))}
                  {/* Accessible spaces inline */}
                  {floor === 'B1' && accessible.slice(0, 1).map(slot => (
                    <div key={slot.id} style={{ height: 72 }}>
                      <ParkingSlotCard slot={slot} selected={selected === slot.id} darkMode={darkMode} onClick={() => setSelected(s => s === slot.id ? null : slot.id)} />
                    </div>
                  ))}
                </div>
              </div>

              {/* Row 2 Zone A */}
              <div className="grid gap-2 mb-3" style={{ gridTemplateColumns: `repeat(5, minmax(0, 1fr))` }}>
                {(floor === 'B1' ? zoneA_row2 : carRow2.slice(0, 5)).map(slot => (
                  <div key={slot.id} style={{ height: 72 }}>
                    <ParkingSlotCard slot={slot} selected={selected === slot.id} darkMode={darkMode} onClick={() => setSelected(s => s === slot.id ? null : slot.id)} />
                  </div>
                ))}
              </div>

              {/* Mid lane with direction arrows */}
              <div className="flex items-center gap-2 my-3">
                <div className="flex-1 h-8 rounded-lg flex items-center justify-center gap-4" style={{ background: laneColor, border: `1px dashed ${darkMode ? 'rgba(255,255,255,0.1)' : '#D1D5DB'}` }}>
                  {['←','←','←','ONE-WAY TRAFFIC','→','→','→'].map((a, i) => (
                    <span key={i} style={{ fontSize: a.length > 3 ? 9 : 12, color: textMuted, fontFamily: "'DM Mono', monospace", fontWeight: 600, letterSpacing: '0.08em' }}>{a}</span>
                  ))}
                </div>
              </div>

              {/* Zone B */}
              <div className="mb-2">
                <div className="flex items-center gap-2 mb-2">
                  <span style={{ fontSize: 10, fontWeight: 700, color: textMuted, letterSpacing: '0.1em', fontFamily: "'DM Mono', monospace" }}>ZONE B</span>
                  <div className="flex-1 h-px" style={{ background: borderColor }} />
                </div>
                <div className="grid gap-2 mb-2" style={{ gridTemplateColumns: `repeat(5, minmax(0, 1fr))` }}>
                  {(floor === 'B1' ? zoneB_row1 : []).map(slot => (
                    <div key={slot.id} style={{ height: 72 }}>
                      <ParkingSlotCard slot={slot} selected={selected === slot.id} darkMode={darkMode} onClick={() => setSelected(s => s === slot.id ? null : slot.id)} />
                    </div>
                  ))}
                  {floor !== 'B1' && carRow2.slice(0, 5).map(slot => (
                    <div key={slot.id} style={{ height: 72 }}>
                      <ParkingSlotCard slot={slot} selected={selected === slot.id} darkMode={darkMode} onClick={() => setSelected(s => s === slot.id ? null : slot.id)} />
                    </div>
                  ))}
                </div>
                <div className="grid gap-2" style={{ gridTemplateColumns: `repeat(5, minmax(0, 1fr))` }}>
                  {(floor === 'B1' ? zoneB_row2 : carRow2.slice(5)).map(slot => (
                    <div key={slot.id} style={{ height: 72 }}>
                      <ParkingSlotCard slot={slot} selected={selected === slot.id} darkMode={darkMode} onClick={() => setSelected(s => s === slot.id ? null : slot.id)} />
                    </div>
                  ))}
                </div>
              </div>

              {/* Bottom lane */}
              <div className="flex items-center gap-2 my-3">
                <div className="flex-1 h-8 rounded-lg flex items-center justify-center gap-4" style={{ background: laneColor, border: `1px dashed ${darkMode ? 'rgba(255,255,255,0.1)' : '#D1D5DB'}` }}>
                  {['→','→','→','ONE-WAY TRAFFIC','→','→','→'].map((a, i) => (
                    <span key={i} style={{ fontSize: a.length > 3 ? 9 : 12, color: textMuted, fontFamily: "'DM Mono', monospace", fontWeight: 600, letterSpacing: '0.08em' }}>{a}</span>
                  ))}
                </div>
              </div>

              {/* Zone C — Special spaces */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">

                {/* EV Charging */}
                <div className="rounded-xl p-3" style={{ background: darkMode ? 'rgba(15,107,79,0.08)' : '#E8F5ED', border: `1.5px solid #0F6B4F` }}>
                  <div className="flex items-center gap-2 mb-2">
                    <BoltIcon className="w-4 h-4" style={{ color: '#0F6B4F' }} />
                    <span style={{ fontSize: 10, fontWeight: 700, color: '#0F6B4F', letterSpacing: '0.08em', fontFamily: "'DM Mono', monospace" }}>EV CHARGING</span>
                  </div>
                  <div className="flex gap-2 flex-wrap">
                    {evSlots.map(slot => (
                      <button key={slot.id} onClick={() => setSelected(s => s === slot.id ? null : slot.id)}
                        className="rounded-lg px-2.5 py-1.5 flex flex-col items-center gap-0.5 transition-all hover:scale-105"
                        style={{
                          background: selected === slot.id ? '#0F6B4F' : (darkMode ? 'rgba(15,107,79,0.15)' : 'rgba(255,255,255,0.8)'),
                          border: `1.5px solid ${selected === slot.id ? '#0F6B4F' : '#22C55E'}`,
                          boxShadow: selected === slot.id ? '0 0 0 2px rgba(15,107,79,0.3)' : 'none',
                        }}>
                        <BoltIcon className="w-4 h-4" style={{ color: selected === slot.id ? 'white' : '#0F6B4F' }} />
                        <span style={{ fontSize: 9, fontWeight: 600, color: selected === slot.id ? 'white' : '#0F6B4F', fontFamily: "'DM Mono', monospace" }}>{slot.id}</span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Motorcycle Zone */}
                <div className="rounded-xl p-3" style={{ background: surface, border: `1px solid ${borderColor}` }}>
                  <div className="flex items-center gap-2 mb-2">
                    <MotoIcon className="w-4 h-4" style={{ color: textMuted }} />
                    <span style={{ fontSize: 10, fontWeight: 700, color: textMuted, letterSpacing: '0.08em', fontFamily: "'DM Mono', monospace" }}>MOTORCYCLE ZONE</span>
                  </div>
                  <div className="flex gap-1.5 flex-wrap">
                    {motoSlots.map(slot => {
                      const cfg = darkMode ? darkStatusConfig[slot.status] : statusConfig[slot.status]
                      return (
                        <button key={slot.id} onClick={() => setSelected(s => s === slot.id ? null : slot.id)}
                          className="rounded-md px-2 py-1 flex flex-col items-center gap-0.5 transition-all hover:scale-105"
                          style={{
                            background: selected === slot.id ? '#0F6B4F' : cfg.bg,
                            border: `1.5px solid ${selected === slot.id ? '#0F6B4F' : cfg.border}`,
                          }}>
                          <MotoIcon className="w-3.5 h-3.5" style={{ color: selected === slot.id ? 'white' : cfg.text }} />
                          <span style={{ fontSize: 8, fontWeight: 600, color: selected === slot.id ? 'white' : cfg.text, fontFamily: "'DM Mono', monospace" }}>{slot.id}</span>
                        </button>
                      )
                    })}
                  </div>
                </div>

                {/* Building core / Facilities */}
                <div className="rounded-xl p-3 flex flex-col gap-2" style={{ background: surface, border: `1px solid ${borderColor}` }}>
                  <span style={{ fontSize: 10, fontWeight: 700, color: textMuted, letterSpacing: '0.08em', fontFamily: "'DM Mono', monospace" }}>FACILITIES</span>
                  <div className="grid grid-cols-2 gap-1.5">
                    {[
                      { label: 'ELEVATOR', icon: '🛗' },
                      { label: 'STAIRS', icon: '🚶' },
                      { label: 'WALKWAY', icon: '→' },
                      { label: 'EXIT', icon: '🚪' },
                    ].map(f => (
                      <div key={f.label} className="rounded-lg px-2 py-1.5 flex items-center gap-1.5"
                        style={{ background: darkMode ? 'rgba(255,255,255,0.04)' : '#F3F4F6' }}>
                        <span style={{ fontSize: 12 }}>{f.icon}</span>
                        <span style={{ fontSize: 9, fontWeight: 600, color: textMuted, letterSpacing: '0.06em', fontFamily: "'DM Mono', monospace" }}>{f.label}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* EXIT label */}
              <div className="flex items-center justify-end gap-3 mt-4">
                <div className="rounded-lg px-3 py-1.5 flex items-center gap-2" style={{ background: '#EF4444' }}>
                  <svg viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" className="w-3.5 h-3.5">
                    <path d="M12 5v14M5 12l7 7 7-7" />
                  </svg>
                  <span style={{ fontSize: 11, fontWeight: 700, color: 'white', letterSpacing: '0.08em', fontFamily: "'DM Mono', monospace" }}>EXIT →</span>
                </div>
              </div>

            </div>
          </div>
        </main>

        {/* ── Detail Panel (side) ── */}
        <aside className="hidden lg:flex flex-col" style={{ width: 280, flexShrink: 0, background: surface, borderLeft: `1px solid ${borderColor}` }}>
          {selectedSlot ? (
            <DetailPanel slot={selectedSlot} darkMode={darkMode} onClose={() => setSelected(null)} />
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center gap-3 p-6">
              <div className="w-14 h-14 rounded-2xl flex items-center justify-center" style={{ background: '#E8F5ED' }}>
                <ParkIcon className="w-7 h-7" style={{ color: '#0F6B4F' }} />
              </div>
              <div className="text-center">
                <div style={{ fontSize: 14, fontWeight: 600, color: textMain }}>Select a parking space</div>
                <div style={{ fontSize: 12, color: textMuted, marginTop: 4 }}>Click any slot on the map to view details and reserve</div>
              </div>
              {/* Quick stats */}
              <div className="w-full mt-4 rounded-xl p-3" style={{ background: '#E8F5ED', border: '1px solid #BBF7D0' }}>
                <div style={{ fontSize: 11, fontWeight: 700, color: '#0F6B4F', letterSpacing: '0.06em', marginBottom: 8, fontFamily: "'DM Mono', monospace" }}>FLOOR {floor} SUMMARY</div>
                <div className="flex justify-between text-sm">
                  <span style={{ color: '#15803D', fontWeight: 600 }}>{stats.available} free</span>
                  <span style={{ color: '#B91C1C', fontWeight: 600 }}>{stats.occupied} taken</span>
                  <span style={{ color: '#92400E', fontWeight: 600 }}>{stats.reserved} reserved</span>
                </div>
                <div className="mt-2 h-2 rounded-full overflow-hidden flex gap-0.5" style={{ background: '#D1FAE5' }}>
                  <div style={{ width: `${Math.round(stats.occupied / stats.total * 100)}%`, background: '#EF4444', height: '100%', borderRadius: 2 }} />
                  <div style={{ width: `${Math.round(stats.reserved / stats.total * 100)}%`, background: '#F59E0B', height: '100%', borderRadius: 2 }} />
                  <div style={{ flex: 1, background: '#22C55E', height: '100%', borderRadius: 2 }} />
                </div>
                <div style={{ fontSize: 10, color: '#15803D', marginTop: 6, fontFamily: "'DM Mono', monospace" }}>
                  {Math.round(stats.available / stats.total * 100)}% capacity available
                </div>
              </div>
            </div>
          )}
        </aside>
      </div>
    </div>
  )
}
